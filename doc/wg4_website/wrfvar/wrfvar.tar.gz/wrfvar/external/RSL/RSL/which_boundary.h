#define WHICH_BDY_EAST   2
#define WHICH_BDY_WEST   1
#define WHICH_BDY_NORTH  8
#define WHICH_BDY_SOUTH  4

